@import "common.js"

handle("settings")
