@import "common.js"

handle("generate")
